from langchain_core.prompts import ChatPromptTemplate
from langchain_community.vectorstores import SQLiteVec
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_nvidia_ai_endpoints import NVIDIAEmbeddings
from langchain_community.document_loaders import TextLoader
from src import base_path, model, nemotron_embed


# 1. Load / Split
raw_documents = TextLoader(str(base_path / "data" / "MEMO.md")).load()
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,
    chunk_overlap=200
)
documents = text_splitter.split_documents(raw_documents)

# 2. Embed / Store - ATTENTION param = db_file ou connection, pas db_path selon version
embedding_model = NVIDIAEmbeddings(model=nemotron_embed)

db = SQLiteVec.from_documents(
    documents,
    embedding_model,
    table_name="memo",
    db_file=str(base_path / "memo" / "memo.db"),
)

retriever = db.as_retriever(search_kwargs={"k": 3})

# 3. Prompt
prompt = ChatPromptTemplate.from_template("""
Tu es expert en Langchain. Tu as une grande mémoire.
Réponds à la question suivant le contexte donné. 
contexte: {context}
question: {question}
""")
chain = prompt | model


def format_docs(docs):
    return "\n\n".join(d.page_content for d in docs)


while True:
    q = input("\nQuelle est ta question ? (q pour quitter) ")
    if q in ["q", "quit", "exit"]:
        break

    # Étape RAG séquentielle, pas parallèle
    docs = retriever.invoke(q)
    context = format_docs(docs)

    print("\n--- REPONSE ---\n", end="")
    for chunk in chain.stream({"context": context, "question": q}):
        print(chunk.content, end="", flush=True)
    print()
