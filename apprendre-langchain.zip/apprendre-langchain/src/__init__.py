from pathlib import Path
from dotenv import load_dotenv
from langchain_nvidia_ai_endpoints import ChatNVIDIA
from langchain_groq import ChatGroq


load_dotenv()

base_path = Path(__file__).parent


deepseek = 'deepseek-ai/deepseek-v4.1-flash'
nemotron = 'nvidia/nemotron-3-super-120b-a12b'
nemotron_ultra = 'nvidia/nemotron-3-ultra-550b-a55b'
llama = 'meta/llama-3.3-70b-instruct'

nemotron_embed = 'nvidia/nemotron-3-embed-1b'

dns_psql = 'postgresql+psycopg://langchain:langchain@localhost:5432/langchain'

model = ChatNVIDIA(
    model=nemotron,
    temperature=0.5,
    max_tokens=1000
)

model_ultra = ChatNVIDIA(
    model=nemotron_ultra,
    temperature=0.5,
    max_tokens=1000
)


model_qwen = ChatGroq(
    model="qwen/qwen3.8-27b",
    temperature=0,
    max_tokens=1000
)
