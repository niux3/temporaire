# Résumé des chapitres

## Chapitre 1

C'est le Hello world de LangChain

- installation
- HumanMessage, SystemMessage
- model
- model invoke
- template prompt
- sortie sous différents formats : json, csv, etc. 
- invoke / batch / stream ==> méthode qui permet de requêter au model
- le chain (prompt | model).{ invoke, batch, stream }()

## Chapitre 2

Introduction à la base de données vectorielle. Comment initialiser un RAG avec PGVector ?

- charger un document (pdf, txt, json, csv, etc.)
- le scinder
- l'encoder (embed)
- l'insérer dans une table vectorielle (PGVector)

## Chapitre 3

Diverses techniques RAG pour un meilleur résultat du model

- Réécrire-Récupérer-Lire (lorsque la question est vague)
- RAG-Fusion (évite que la réponse se répète)
- HyDE (invente un document qui répond à la question)
- Filtre texte-métadonnées (insertion de tags lors de PGVector, etc.)
- Routage Logique (Analyse la question du client pour l'aiguiller vers la bonne branche (retriever / collection / prompt) qui va produire la bonne réponse. )
- Routage Sémantique (Embed la question (On transforme la question du client en chiffre) et l'aiguille vers la route la plus proche sémantiquement.)
- Du texte à SQL (fait une recherche en base de données, mais donne la requête SQL pour le faire manuellement)

## Chapitre 4

Création d'un système de mémoire et d'état pour un agent

- petite révision du chapitre 1
- installation langgraph
- création d'un state
- déclaration builder en tant que StateGraph(State)
- explication du principe add_node (élément à insérer) et add_edge (scénario de la requête)
- compilation du builder
- notion d'ajout de mémoire au model (mais n'est pas suffisant si trop d'utilisateurs, il faut se tourner vers des outils comme Mongo ou PosgreSQL)
- modification de l'historique de discussion
- filtrage des messages afin d'éviter de dépenser trop de tokens
- fusion des messages consécutifs (je veux un jeu gore + avec des zombies)

## Chapitre 5

petite révision du chapitre 4. Création simple d'un agent. 

- création d'un state
- creation d'input et output (permet de filtrer ce qui va entrer et sortir en fonction des mini agents)
- le chain est une technique de scénario (add_edge). 
- création d'un router qui décide de la route (add_conditional_edges)
