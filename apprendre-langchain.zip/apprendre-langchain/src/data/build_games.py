import requests
from pathlib import Path
from src import base_path

# 1. On va chercher 200 jeux (gratuit, pas de clé)
url = "https://www.freetogame.com/api/games"
games = requests.get(url, timeout=10).json()
print(f"API a renvoyé {len(games)} jeux")

# 2. On transforme en fichier riche, pas juste "nom - genre"
lines = []
lines.append("CATALOGUE JEUX VIDEO MC PIXEL - VERSION RAG 2026")
lines.append("="*50)
for j in games:
    # On fait une vraie fiche comme un vendeur la décrirait
    # C'est ça qui va aider ton embed model
    fiche = (
        f"TITRE: {j['title']}\n"
        f"GENRE: {j['genre']} / {j.get('short_description', '')}\n"
        f"GAMEPLAY: {j['short_description']} Plateforme: {j['platform']} Editeur: {j['publisher']}\n"
        f"TAGS: {j['genre']}, {j['platform']}, {j['publisher']}\n"
        f"---\n"
    )
    lines.append(fiche)

# 3. On écrit
out_path = base_path / "data" / "jeux-videos.txt"
out_path.write_text("\n".join(lines), encoding="utf-8")

print(f"Fichier généré: {out_path}")
print(f"Taille: {out_path.stat().st_size / 1024:.1f} ko")
print(f"Lignes: {len(lines)}")
# Tu dois voir: Taille: 60-80 ko, Lignes: ~1000
