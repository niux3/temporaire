from typing import Annotated, TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langchain_core.messages import HumanMessage, AIMessage
import operator

# ============ VRAI RAG : EMBED + PGVECTOR ============
# pip install langchain-nvidia-ai-endpoints langchain-postgres pgvector psycopg2-binary
from langchain_nvidia_ai_endpoints import ChatNVIDIA, NVIDIAEmbeddings
from langchain_postgres import PGVector
from langchain_core.documents import Document

# Tes modèles Nemotron
model = ChatNVIDIA(model="meta/llama-3.1-70b-instruct")  # ton src.model
embed_model = NVIDIAEmbeddings(model="nvidia/nv-embedqa-e5-v5")  # 1024 dims

# Config pgvector - même que ton projet Lefebvre Dalloz / Chinook
CONNECTION_STRING = "postgresql+psycopg://user:password@localhost:5432/jeux_db"
COLLECTION_NAME = "jeux_video_catalogue"

CATALOGUE_PATH = "/mnt/data/jeux-videos.txt"

# ============ 1. STATE RICHE ============


class GameRecommenderState(TypedDict):
    messages: Annotated[list, add_messages]
    envie_originale: str
    envie_reecrite: str
    genre_demande: str
    tags_demandes: list
    # pgvector sort ici
    query_embedding: list  # le vecteur de "gore où on tire"
    jeux_trouves: list  # les Documents pgvector retrouvés avec score
    nombre_trouves: int
    player_id: str
    rage_level: Annotated[int, operator.add]

# ============ 2. OUTILS PGVECTOR ============


def charger_documents():
    """Transforme jeux-videos.txt en Documents pour pgvector"""
    with open(CATALOGUE_PATH, encoding="utf-8", errors="ignore") as f:
        text = f.read()

    docs = []
    for block in text.split("---"):
        block = block.strip()
        if not block.startswith("TITRE:"):
            continue
        d = {}
        for line in block.splitlines():
            if ":" in line:
                k, v = line.split(":", 1)
                d[k.strip().lower()] = v.strip()

        # Le texte qu'on va embedder : TOUT le jeu
        page_content = f"TITRE: {d.get('titre', '')} GENRE: {d.get('genre', '')} DESCRIPTION: {d.get('description', '')} TAGS: {d.get('tags', '')}"

        docs.append(Document(
            page_content=page_content,
            metadata={"titre": d.get('titre'), "genre": d.get(
                'genre'), "tags": d.get('tags')}
        ))
    return docs


def get_vectorstore():
    """Crée ou charge le vectorstore pgvector"""
    # Si la table n'existe pas, on l'initialise avec les 418 jeux
    # En prod tu fais ça une seule fois au démarrage
    docs = charger_documents()

    vectorstore = PGVector.from_documents(
        documents=docs,
        embedding=embed_model,
        collection_name=COLLECTION_NAME,
        connection=CONNECTION_STRING,
        use_jsonb=True,
    )
    return vectorstore

# Tu appelles ça UNE FOIS au setup, pas à chaque requête
# vectorstore = get_vectorstore()

# Pour le test on simule le vectorstore (si tu n'as pas postgres lancé)
# En vrai tu fais: vectorstore = PGVector(..., embedding=embed_model)

# ============ 3. NODES avec EMBED ============


def chatbot_accueil(state: GameRecommenderState):
    last_msg = state["messages"][-1].content if state["messages"] else ""
    print(f"\n[CHATBOT] Gamin: {last_msg}")
    return {
        "envie_originale": last_msg,
        "player_id": state.get("player_id", "gamin_rageux_12"),
        "rage_level": 0
    }


def reecrire_demande(state: GameRecommenderState):
    """Node RRR : Réécrire avec LLM, pas avec if 'gore' in..."""
    original = state["envie_originale"]

    # VRAI RRR avec ton Nemotron
    prompt = f"""Tu es un expert catalogue jeux.
    Réécris la demande d'un gamin rageux en mots-clés pour recherche vectorielle.
    Demande: "{original}"
    Exemple: "Je veux un jeu gore où on tire" -> "jeu de tir gore horreur survival zombie sanglant FPS"
    Réponds UNIQUEMENT par la requête réécrite, sans phrase."""

    # Si tu as model:
    reecrite = model.invoke(prompt).content.strip()
    # Sinon fallback:
    # reecrite = "jeu de tir gore horreur survival zombie sanglant FPS"

    print(f"[RRR + LLM] '{original}' -> '{reecrite}'")

    # EMBED de la requête réécrite
    # C'est ici que pgvector intervient
    query_embedding = embed_model.embed_query(reecrite)

    return {
        "envie_reecrite": reecrite,
        "query_embedding": query_embedding,
        "genre_demande": "Jeu de tir",
        "tags_demandes": reecrite.split(),
        "messages": [AIMessage(content=f"Ok, je cherche: {reecrite}")]
    }


def chercher_dans_pgvector(state: GameRecommenderState):
    """Node Fusion : recherche par similarité cosinus dans pgvector"""
    query_reecrite = state["envie_reecrite"]
    # embedding déjà calculé dans le node précédent
    # query_embedding = state["query_embedding"]

    # VRAIE RECHERCHE PGVECTOR
    # vectorstore = PGVector(collection_name=COLLECTION_NAME, connection=CONNECTION_STRING, embedding_function=embed_model)
    # résultats = vectorstore.similarity_search_with_score(query_reecrite, k=5)
    # résultats = [(Document, score), ...] score = distance cosinus, plus petit = plus proche

    # SIMULATION pour que ça tourne sans postgres (tu remplaces par les 2 lignes au-dessus)
    # On simule ce que pgvector retournerait pour "gore où on tire"
    from langchain_core.documents import Document
    sim_results = [
        (Document(page_content="TITRE: No More Room in Hell GENRE: Jeu de tir DESCRIPTION: jeu de tir zombies gore horreur survival",
         metadata={"titre": "No More Room in Hell"}), 0.21),
        (Document(page_content="TITRE: Once Human GENRE: Jeu de tir DESCRIPTION: survival horreur monde ouvert",
         metadata={"titre": "Once Human"}), 0.28),
        (Document(page_content="TITRE: Undawn GENRE: Jeu de tir DESCRIPTION: survival horreur zombie",
         metadata={"titre": "Undawn"}), 0.31),
    ]

    # En vrai:
    # vectorstore = PGVector(...)
    # sim_results = vectorstore.similarity_search_with_score(query_reecrite, k=5)

    jeux = [doc for doc, score in sim_results]

    print(f"[PGVECTOR SEARCH] Query='{query_reecrite}'")
    print(
        f"  Embedding dim: {len(state.get('query_embedding', []))} (nv-embedqa-e5-v5 = 1024)")
    for doc, score in sim_results:
        print(f"  - score {score:.2f} -> {doc.metadata['titre']}")

    reponse = f"En gore où on tire, le meilleur match vectoriel est **{jeux[0].metadata['titre']}** (distance {sim_results[0][1]}). J'ai trouvé {len(jeux)} jeux."

    return {
        "jeux_trouves": [j.metadata for j in jeux],
        "nombre_trouves": len(jeux),
        "messages": [AIMessage(content=reponse)]
    }


# ============ 4. BUILDER ============
builder = StateGraph(GameRecommenderState)

builder.add_node("chatbot", chatbot_accueil)
builder.add_node("rrr", reecrire_demande)  # ici on EMBED
builder.add_node("fusion", chercher_dans_pgvector)  # ici on SEARCH PGVECTOR

builder.add_edge(START, "chatbot")
builder.add_edge("chatbot", "rrr")
builder.add_edge("rrr", "fusion")
builder.add_edge("fusion", END)

graph = builder.compile()

# ============ 5. TEST ============
if __name__ == "__main__":
    input_state = {
        "messages": [HumanMessage(content="Je veux un jeu gore ou on tire")],
        "player_id": "gamin_rageux_12",
        "rage_level": 0,
        "envie_originale": "",
        "envie_reecrite": "",
        "genre_demande": "",
        "tags_demandes": [],
        "query_embedding": [],
        "jeux_trouves": [],
        "nombre_trouves": 0
    }

    print("\n=== TEST AVEC EMBED + PGVECTOR ===")
    # result = graph.invoke(input_state)
    # print(result["messages"][-1].content)

    print("1. Charge les 418 jeux -> embed avec nvidia/nv-embedqa-e5-v5")
    print("2. Stocke dans postgres + pgvector (extension vector)")
    print("3. Embed la requête 'gore où on tire' -> vecteur 1024 dims")
    print("4. SELECT * FROM jeux_video_catalogue ORDER BY embedding <=> query_embedding LIMIT 5")
    print("   <=> c'est l'opérateur distance cosinus de pgvector")
