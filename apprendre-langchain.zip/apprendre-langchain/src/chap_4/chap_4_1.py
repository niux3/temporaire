from typing import Annotated, TypedDict
from src import model
from langchain_core.messages import HumanMessage
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages

# 1. C'est quoi la mémoire du bot?
# Tu dis: mon bot se souviendra d'une seule chose -> une liste de messages
# add_messages = "quand tu reçois un nouveau message, ajoute-le, n'écrase pas l'ancien"
# Sans ça, à chaque tour tu perdrais la conversation de l'élève eleve_12


class State(TypedDict):
    messages: Annotated[list, add_messages]


# 2. Que vient faire builder = StateGraph(State)?
# C'est la ligne qui te bloque. Pense Lego:
# State = le plan qui dit "ma Lego box contient une liste"
# StateGraph(State) = tu prends une boite Lego vide et tu colles le plan dessus
# Tu as une boite vide, mais elle sait déjà qu'elle ne contiendra que des messages
# Tu n'as encore AUCUN noeud, AUCUN tuyau. Juste une boite vide avec étiquette.
builder = StateGraph(State)

# 3. Le travail à faire (un noeud = une fonction qui prend la mémoire et rend un bout de mémoire)


def chatbot(state: State):
    answer = model.invoke(state["messages"])  # il lit toute la mémoire
    return {"messages": [answer]}  # il rend un nouveau message à ajouter


# 4. Tu mets la pièce dans la boite
# "dans ma boite, il y a une pièce qui s'appelle chatbot"
builder.add_node("chatbot", chatbot)

# 5. Tu branches les tuyaux
builder.add_edge(START, 'chatbot')  # quand on lance, on va direct à chatbot
builder.add_edge('chatbot', END)  # quand chatbot a fini, on s'arrête

# 6. Tu fermes la boite — ça devient un objet qu'on peut exécuter
graph = builder.compile()

# 7. Test
# graph.get_graph().draw_mermaid_png() # pour voir le dessin START -> chatbot -> END
for chunk in graph.stream({"messages": [HumanMessage('Salut!!')]}):
    print(chunk)
