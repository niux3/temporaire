"""
bot_jeux_final.py - Version de référence pour le cours
Catalogue: jeux-videos.txt -> pgvector
Bot: gamin rageux "Je veux un jeu gore où on tire"
Stack: LangGraph + NVIDIA Embed + PGVector + filter_messages + SqliteSaver
"""
from typing import Annotated, TypedDict
import operator
import sqlite3

# ============ 1. TA BASE INTACTE ============
from src import base_path, nemotron_embed, dns_psql, model
from langchain_community.document_loaders import TextLoader
from langchain_nvidia_ai_endpoints import NVIDIAEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_postgres import PGVector
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage, filter_messages
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.checkpoint.sqlite import SqliteSaver

# Load + Split + Embed + PGVector (ta base de l'énoncé)
raw_documents = TextLoader(str(base_path / "data" / "jeux-videos.txt")).load()
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000, chunk_overlap=200)
documents = text_splitter.split_documents(raw_documents)

embedding_model = NVIDIAEmbeddings(model=nemotron_embed)
db = PGVector.from_documents(documents, embedding_model, connection=dns_psql)

print(f"Catalogue chargé: {len(documents)} chunks dans pgvector")

# ============ 2. STATE RICHE ============


class GameRecommenderState(TypedDict):
    messages: Annotated[list, add_messages]
    envie_originale: str
    envie_reecrite: str
    jeux_trouves: list
    nombre_trouves: int
    player_id: str
    rage_level: Annotated[int, operator.add]

# ============ 3. NODES ============


def chatbot_accueil(state: GameRecommenderState):
    last_msg = state["messages"][-1].content
    print(f"\n[CHATBOT] Gamin ({state.get('player_id')}): {last_msg}")
    return {
        "envie_originale": last_msg,
        "player_id": state.get("player_id", "gamin_rageux_12"),
        "rage_level": 0
    }


def reecrire_demande(state: GameRecommenderState):
    """
    Pattern complet: FILTRE -> RRR -> EMBED
    1. filter_messages pour ne garder que ce qui sert (économie tokens)
    2. RRR avec Nemotron pour clarifier
    """
    # ÉTAPE 1 : FILTRE - on ne garde que les vrais messages du gamin
    # On enlève SystemMessage et les examples pour ne pas payer pour rien
    messages_utiles = filter_messages(
        state["messages"],
        include_types=[HumanMessage]
    )
    # Pour 1M users: on ne prend que les 3 derniers messages du gamin
    messages_utiles = messages_utiles[-3:]

    historique = "\n".join([m.content for m in messages_utiles])
    print(f"[FILTRE] Historique gardé pour RRR: {historique}")

    # ÉTAPE 2 : RRR - Réécriture avec ton model Nemotron
    prompt = f"""Tu es un expert catalogue jeux.
    Reformule la dernière demande en requête standalone pour recherche vectorielle.
    Historique:
    {historique}
    
    Consigne: Réponds UNIQUEMENT par la requête réécrite.
    Exemple: "Et avec des zombies" + historique "Je veux un jeu gore où on tire" -> "Je veux un jeu gore où on tire avec des zombies"
    """

    reecrite = model.invoke(prompt).content.strip()
    print(f"[RRR] '{state['envie_originale']}' -> '{reecrite}'")

    return {
        "envie_reecrite": reecrite,
        "messages": [AIMessage(content=f"Ok je cherche: {reecrite}")]
    }


def chercher_dans_pgvector(state: GameRecommenderState):
    """
    RAG Fusion avec ta variable db
    """
    query = state["envie_reecrite"]

    # Recherche sémantique dans pgvector
    # Bob "Je veux des jeux gore où on tire" et Alice "Je souhaite un jeu où il y a du sang et je tire"
    # vont retomber sur le même résultat grâce à l'embedding, pas grâce à filter_messages
    results = db.similarity_search_with_score(query, k=5)

    print(f"[PGVECTOR] Query: '{query}'")
    for doc, score in results:
        print(f"  - distance {score:.3f} -> {doc.page_content[:80]}...")

    # ÉTAPE 4 : RE-FILTRE avant réponse finale (économie tokens)
    # On ne garde que 3 derniers messages pour construire la réponse
    contexte_court = filter_messages(state["messages"], include_types=[
                                     HumanMessage, AIMessage])[-3:]

    # Construction réponse
    if results:
        top_doc = results[0][0]
        reponse = f"Pour '{query}', je te conseille **{top_doc.metadata.get('titre', 'No More Room in Hell')}** : {top_doc.page_content[:200]}"
    else:
        reponse = "J'ai rien trouvé, tente PUBG en Jeu de tir."

    return {
        "jeux_trouves": results,
        "nombre_trouves": len(results),
        "messages": [AIMessage(content=reponse)]
    }


# ============ 4. BUILDER AVEC SQLITE ============
builder = StateGraph(GameRecommenderState)

builder.add_node("chatbot", chatbot_accueil)
builder.add_node("rrr", reecrire_demande)  # Filtre + RRR
builder.add_node("fusion", chercher_dans_pgvector)  # PGVector + Re-filtre

builder.add_edge(START, "chatbot")
builder.add_edge("chatbot", "rrr")
builder.add_edge("rrr", "fusion")
builder.add_edge("fusion", END)

# Checkpointer: SqliteSaver pour 30 élèves (pas MemorySaver qui explose en RAM)
conn = sqlite3.connect(
    str(base_path / "checkpoints_gamins.db"), check_same_thread=False)
checkpointer = SqliteSaver(conn)

# Pour 1M users, remplacer par:
# from langgraph.checkpoint.postgres import PostgresSaver
# checkpointer = PostgresSaver.from_conn_string(dns_psql)
# checkpointer.setup()

graph = builder.compile(checkpointer=checkpointer)

# ============ 5. TEST ============
if __name__ == "__main__":
    config = {"configurable": {"thread_id": "gamin_rageux_12"}}

    print("\n=== TOUR 1: 'Je veux un jeu gore ou on tire' ===")
    result = graph.invoke(
        {"messages": [HumanMessage(content="Je veux un jeu gore ou on tire", name="bob")],
         "player_id": "gamin_rageux_12", "rage_level": 0,
         "envie_originale": "", "envie_reecrite": "", "jeux_trouves": [], "nombre_trouves": 0},
        config=config
    )
    print(result["messages"][-1].content)

    print("\n=== TOUR 2: 'Et avec des zombies' (mémoire sqlite) ===")
    result2 = graph.invoke(
        {"messages": [HumanMessage(
            content="Et avec des zombies", name="bob")]},
        config=config
    )
    print(result2["messages"][-1].content)

    print("\n=== Checkpoints sauvés dans checkpoints_gamins.db (pas en RAM) ===")
