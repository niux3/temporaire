from typing import Annotated, TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langchain_core.messages import HumanMessage, AIMessage
import operator

# ===== TA BASE - INTACTE =====
from src import base_path, nemotron_embed, dns_psql, model  # ton Nemotron Chat
from langchain_community.document_loaders import TextLoader
from langchain_nvidia_ai_endpoints import NVIDIAEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_postgres import PGVector

raw_documents = TextLoader(str(base_path / "data" / "jeux-videos.txt")).load()
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,
    chunk_overlap=200
)
documents = text_splitter.split_documents(raw_documents)

embedding_model = NVIDIAEmbeddings(model=nemotron_embed)
db = PGVector.from_documents(documents, embedding_model, connection=dns_psql)

# ===== STATE RICHE - avec embedding + pgvector =====


class GameRecommenderState(TypedDict):
    messages: Annotated[list, add_messages]

    envie_originale: str
    envie_reecrite: str  # RRR
    query_embedding: list  # le vecteur 1024 dims

    jeux_trouves: list  # résultats pgvector
    nombre_trouves: int

    player_id: str
    rage_level: Annotated[int, operator.add]

# ===== NODES =====


def chatbot_accueil(state: GameRecommenderState):
    last_msg = state["messages"][-1].content
    print(f"\n[CHATBOT] Gamin: {last_msg}")
    return {
        "envie_originale": last_msg,
        "player_id": "gamin_rageux_12",
        "rage_level": 0
    }


def reecrire_demande(state: GameRecommenderState):
    """RRR avec ton Nemotron + embed"""
    original = state["envie_originale"]

    prompt = f"""Réécris la demande du gamin en requête pour recherche vectorielle.
    Demande: "{original}"
    Exemple: "Je veux un jeu gore ou on tire" -> "jeu de tir gore horreur survival zombie FPS sanglant"
    Réponds UNIQUEMENT la requête réécrite."""

    reecrite = model.invoke(prompt).content.strip()
    query_embedding = embedding_model.embed_query(reecrite)

    print(
        f"[RRR] '{original}' -> '{reecrite}' | embedding dim={len(query_embedding)}")

    return {
        "envie_reecrite": reecrite,
        "query_embedding": query_embedding,
        "messages": [AIMessage(content=f"Ok je cherche: {reecrite}")]
    }


def chercher_dans_pgvector(state: GameRecommenderState):
    """RAG Fusion avec TA variable db"""
    query = state["envie_reecrite"]

    # C'est ta variable db qui fait le SELECT... ORDER BY embedding <=> query
    results = db.similarity_search_with_score(query, k=5)
    # results = [(Document, distance),...]

    print(f"[PGVECTOR] Recherche: '{query}'")
    for doc, score in results:
        titre = doc.metadata.get('titre', doc.page_content[:30])
        print(f" - score {score:.3f} -> {titre}")

    jeux = [doc for doc, score in results]
    reponse = f"Pour '{state['envie_originale']}', je te conseille **{jeux[0].metadata.get('titre', 'No More Room in Hell')}** (match pgvector)."

    return {
        "jeux_trouves": results,
        "nombre_trouves": len(results),
        "messages": [AIMessage(content=reponse)]
    }


# ===== BUILDER =====
builder = StateGraph(GameRecommenderState)

builder.add_node("chatbot", chatbot_accueil)
builder.add_node("rrr", reecrire_demande)  # embed ici
builder.add_node("fusion", chercher_dans_pgvector)  # pgvector search ici

builder.add_edge(START, "chatbot")
builder.add_edge("chatbot", "rrr")
builder.add_edge("rrr", "fusion")
builder.add_edge("fusion", END)

graph = builder.compile()

# ===== TEST GAMIN =====
if __name__ == "__main__":
    input_state = {
        "messages": [HumanMessage(content="Je veux un jeu gore ou on tire")],
        "player_id": "gamin_rageux_12",
        "rage_level": 0,
        "envie_originale": "",
        "envie_reecrite": "",
        "query_embedding": [],
        "jeux_trouves": [],
        "nombre_trouves": 0
    }

    print("=== GAMIN: 'Je veux un jeu gore ou on tire' ===")
    result = graph.invoke(input_state)
    print("\n" + result["messages"][-1].content)

