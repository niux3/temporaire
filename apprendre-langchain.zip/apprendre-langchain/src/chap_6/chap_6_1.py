import ast
from typing import Annotated, TypedDict
from langchain_groq import ChatGroq
from langchain_community.tools import DuckDuckGoSearchRun
from langchain_core.tools import tool
from langchain_core.messages import HumanMessage
from langgraph.graph import StateGraph, START
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode, tools_condition


model = ChatGroq(
    model="qwen/qwen3.8-27b",
    temperature=0,
    max_tokens=1000
)


@tool
def calculator(query: str) -> str:
    """A simple calculator tool. Input should be a mathematical expression."""
    return ast.literal_eval(query)


search = DuckDuckGoSearchRun()
tools = [
    search,
    calculator,
]
model_with_tools = model.bind_tools(tools)


class State(TypedDict):
    messages: Annotated[list, add_messages]


def model_node(state: State) -> State:
    res = model_with_tools.invoke(state["messages"])
    return {"messages": [res]}


builder = StateGraph(State)
builder.add_node("model", model_node)
builder.add_node("tools", ToolNode(tools))

builder.add_edge(START, "model")
builder.add_conditional_edges("model", tools_condition)
builder.add_edge("tools", "model")

graph = builder.compile()

if __name__ == "__main__":
    while True:
        q = input("\nQuelle est ta question ? (q pour quitter) ")
        if q in ["q", "quit", "exit"]:
            break
        ask = {
            "messages": [
                HumanMessage(q)
            ]
        }

        print("--- STREAM ---")
        for chunk in graph.stream(ask):
            for node_name, node_data in chunk.items():
                msg = node_data["messages"][-1]
                # On n'affiche pas tout le reasoning_content de 1000 tokens
                if hasattr(msg, 'tool_calls') and msg.tool_calls:
                    print(f"[{node_name}] Appelle: {msg.tool_calls}")
                elif msg.content:
                    print(f"[{node_name}] {msg.content[:200]}")
                else:
                    print(f"[{node_name}] (réflexion interne...)")
        # Réponse finale propre
        final_state = graph.invoke(ask)
        final_answer = final_state["messages"][-1].content
        print("\n--- RÉPONSE FINALE ---")
        print(final_answer)
