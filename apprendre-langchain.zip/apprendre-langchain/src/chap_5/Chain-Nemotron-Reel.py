"""
chain_nemotron_reel.py
Architecture #2 : Chain en condition réelle avec ton Nemotron 3

C'est la version du fichier chap-5.html lignes 320-482,
mais adaptée à ton setup et thème jeux vidéo.
"""

from typing import TypedDict, Annotated
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langchain_core.messages import HumanMessage, SystemMessage

# Ton modèle Nemotron - importe depuis ton model.py
# Si tu es dans le dossier du cours : from model import model, strong_model
# Ici on garde ta config exacte :
from pathlib import Path
from dotenv import load_dotenv
import os
from langchain_nvidia_ai_endpoints import ChatNVIDIA

load_dotenv(dotenv_path=Path(__file__).resolve().parent / ".env", override=True)

NVIDIA_API_KEY = os.getenv("NVIDIA_API_KEY")
if not NVIDIA_API_KEY:
    raise ValueError("NVIDIA_API_KEY manquant dans .env")

# Modèle froid = pour générer (précis) - remplace model_low_temp du livre
model_nemotron = 'nvidia/nemotron-3-super-120b-a12b'
model_low_temp = ChatNVIDIA(
    model=model_nemotron,
    nvidia_api_key=NVIDIA_API_KEY,
    temperature=0.1,  # froid = précis, pour trouver le jeu
)

# Modèle chaud = pour expliquer (créatif) - remplace model_high_temp
model_nemotron_ultra = 'nvidia/nemotron-3-ultra-550b-a55b'
model_high_temp = ChatNVIDIA(
    model=model_nemotron_ultra,
    nvidia_api_key=NVIDIA_API_KEY,
    temperature=0.7,  # chaud = bavard, pour expliquer au gamin
)

# ============ 1. LES 3 BOITES (State / Input / Output) ============

class GameState(TypedDict):
    # Tout ce que les ouvriers se passent en interne
    messages: Annotated[list, add_messages]
    envie_gamin: str      # input
    jeu_trouve: str       # généré par ouvrier 1
    pourquoi_ce_jeu: str  # généré par ouvrier 2

class GameInput(TypedDict):
    # Ce que le gamin a le droit d'envoyer à l'invoke
    envie_gamin: str

class GameOutput(TypedDict):
    # Ce que le gamin verra à la fin (messages est caché)
    jeu_trouve: str
    pourquoi_ce_jeu: str


# ============ 2. LES 2 OUVRIERS ============

generate_prompt = SystemMessage(
    content="""Tu es un expert jeux vidéo.
Ta tâche : à partir de l'envie du gamin, propose UN SEUL jeu vidéo.
Réponds uniquement avec le nom du jeu, rien d'autre.
Exemples: DOOM Eternal, Mario Odyssey, Elden Ring"""
)

explain_prompt = SystemMessage(
    content="""Tu es un vendeur de jeux vidéo cool qui parle à un gamin.
On te donne un jeu. Explique en 2 phrases max, style gamin, pourquoi ce jeu est parfait pour lui.
Utilise un ton fun, pas technique."""
)

def trouver_jeu(state: GameState):
    """Ouvrier 1 : froid, précis. Comme generate_sql dans le livre."""
    user_message = HumanMessage(content=state["envie_gamin"])
    messages = [generate_prompt, *state["messages"], user_message]

    res = model_low_temp.invoke(messages)

    print(f"[OUVRIER 1 - {model_nemotron}] -> {res.content}")

    return {
        "jeu_trouve": res.content.strip(),
        "messages": [user_message, res]
    }

def expliquer_jeu(state: GameState):
    """Ouvrier 2 : chaud, créatif. Comme explain_sql dans le livre."""
    # On lui donne le jeu trouvé par ouvrier 1
    context_message = HumanMessage(content=f"Le jeu trouvé est : {state['jeu_trouve']}")
    messages = [explain_prompt, *state["messages"], context_message]

    res = model_high_temp.invoke(messages)

    print(f"[OUVRIER 2 - {model_nemotron_ultra}] -> {res.content}")

    return {
        "pourquoi_ce_jeu": res.content.strip(),
        "messages": [res]
    }

# ============ 3. LA CHAINE ============

builder = StateGraph(GameState, input=GameInput, output=GameOutput)
builder.add_node("trouver", trouver_jeu)
builder.add_node("expliquer", expliquer_jeu)

builder.add_edge(START, "trouver")
builder.add_edge("trouver", "expliquer")
builder.add_edge("expliquer", END)

graph = builder.compile()

# Dessine comme dans le livre
# graph.get_graph().draw_mermaid_png() -> figure 5-3

# ============ 4. TEST REEL ============

if __name__ == "__main__":
    print("=== Test Chain Nemotron ===\n")

    # Le gamin ne peut envoyer QUE envie_gamin (Input)
    # Si tu essaies {"pourquoi_ce_jeu": "triche"} -> erreur
    result = graph.invoke({
        "envie_gamin": "jveux un jeu gore où on tir avec un shotgun"
    })

    print("\n=== RESULTAT FINAL (Output) ===")
    print(f"Jeu : {result['jeu_trouve']}")
    print(f"Pourquoi : {result['pourquoi_ce_jeu']}")
    print(f"\nMessages cachés ? {'messages' in result} -> {result.get('messages') is None} (normal, pas dans Output)")

    # Deuxième test
    print("\n\n=== Deuxième test ===")
    result2 = graph.invoke({
        "envie_gamin": "jveux un jeu chill où on saute partout"
    })
    print(f"Jeu : {result2['jeu_trouve']}")
    print(f"Pourquoi : {result2['pourquoi_ce_jeu']}")
