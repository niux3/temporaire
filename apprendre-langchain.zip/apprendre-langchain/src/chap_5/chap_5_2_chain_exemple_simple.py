"""
Architecture #2 : Chain
Thème : jeux vidéo

But : comprendre à quoi servent Input et Output
"""

from typing import TypedDict, Annotated
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages

# On simule un LLM pour que tu puisses lancer sans clé API
# Remplace par from src import model si tu veux ton Nemotron


def fake_llm(prompt: str) -> str:
    if "gore" in prompt.lower() or "tire" in prompt.lower():
        return "DOOM Eternal"
    return "Stardew Valley"

# ============ 1. LES 3 BOITES ============


class GameState(TypedDict):
    """
    STATE = TOUT le magasin, réserve comprise.
    C'est ce que les ouvriers se passent entre eux en interne.
    """
    messages: Annotated[list, add_messages]  # historique complet
    envie_gamin: str          # ce que dit le gamin
    jeu_trouve: str            # résultat technique de l'ouvrier 1
    pourquoi_ce_jeu: str       # explication de l'ouvrier 2


class GameInput(TypedDict):
    """
    INPUT = Le videur à l'entrée.
    Le gamin ne peut DONNER que ça.
    Il ne peut pas tricher et donner directement jeu_trouve.
    """
    envie_gamin: str


class GameOutput(TypedDict):
    """
    OUTPUT = Le sac à la sortie.
    Le gamin ne peut RAMENER que ça.
    Il ne voit pas tout l'historique messages.
    """
    jeu_trouve: str
    pourquoi_ce_jeu: str

# ============ 2. LES 2 OUVRIERS (CHAIN) ============


def trouver_jeu(state: GameState):
    """
    Ouvrier 1 : le vendeur technique.
    Froid, précis, il cherche dans le catalogue.
    """
    envie = state["envie_gamin"]
    print(f"[OUVRIER 1 - TROUVER] Gamin veut : '{envie}'")

    # Ici tu appellerais ton LLM froid : model_low_temp.invoke(...)
    jeu = fake_llm(envie)

    print(f"[OUVRIER 1] J'ai trouvé : {jeu}")

    # Il remplit jeu_trouve dans le State
    # Il ajoute aussi un message interne (qui ne sortira pas car pas dans Output)
    return {
        "jeu_trouve": jeu,
        "messages": [f"ouvrier1: j'ai trouvé {jeu} pour '{envie}'"]
    }


def expliquer_jeu(state: GameState):
    """
    Ouvrier 2 : le vendeur cool.
    Chaud, bavard, il explique au gamin.
    Il a besoin du résultat de l'ouvrier 1.
    """
    jeu = state["jeu_trouve"]
    print(f"[OUVRIER 2 - EXPLIQUER] On m'a donné : {jeu}")

    # Ici tu appellerais ton LLM chaud : model_high_temp.invoke(...)
    if jeu == "DOOM Eternal":
        explication = "C'est ultra gore, tu tires sur des démons avec un shotgun, parfait pour toi !"
    else:
        explication = "C'est chill, tu plantes des carottes, parfait pour te calmer."

    print(f"[OUVRIER 2] Explication : {explication}")

    return {
        "pourquoi_ce_jeu": explication,
        "messages": [f"ouvrier2: explication pour {jeu}"]
    }

# ============ 3. LA CHAINE DE MONTAGE ============


# On dit à LangGraph : voici la grosse boite (State)
# mais le client ne peut entrer que Input et sortir que Output
builder = StateGraph(GameState, input=GameInput, output=GameOutput)

builder.add_node("trouver", trouver_jeu)
builder.add_node("expliquer", expliquer_jeu)

# Ordre FIXE : toujours trouver -> expliquer
# C'est ça une Chain (figure 5-3 du chapitre)
builder.add_edge(START, "trouver")
builder.add_edge("trouver", "expliquer")
builder.add_edge("expliquer", END)

graph = builder.compile()

# ============ 4. TEST ============

if __name__ == "__main__":

    print("=== Le gamin arrive au magasin ===\n")

    # Le gamin ne peut envoyer QUE ce que GameInput autorise
    # Essaie d'envoyer {"jeu_trouve": "triche"} -> LangGraph va refuser
    entree_gamin = {
        "envie_gamin": "Je veux un jeu gore où on tire"
    }

    print(f"INPUT du gamin : {entree_gamin}\n")

    resultat = graph.invoke(entree_gamin)

    print("\n=== Le gamin repart avec son sac ===\n")
    print(f"OUTPUT complet : {resultat}")
    print("\nCe qu'il voit vraiment :")
    print(f"  - Jeu : {resultat['jeu_trouve']}")
    print(f"  - Pourquoi : {resultat['pourquoi_ce_jeu']}")

    print("\nCe qu'il ne voit PAS (caché par Output) :")
    print(
        f"  - messages internes : {resultat.get('messages')} -> None, c'est normal !")
    print(
        f"  - envie_gamin : {resultat.get('envie_gamin')} -> None, c'est normal !")

    print("\n=== Feynman en 1 phrase ===")
    print("State = tout le magasin, Input = ce que tu donnes à l'entrée, Output = ce que tu ramènes.")
