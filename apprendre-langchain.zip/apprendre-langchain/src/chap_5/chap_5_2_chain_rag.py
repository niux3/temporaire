"""
chap_5_2_chain.py - Version corrigée sans SqliteSaver
Chain: fichier jeux -> parse -> filter PC -> template
"""
from typing import Annotated, TypedDict
import operator

# Remplacement du TextLoader déprécié
from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage, filter_messages
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages

# FIX du ModuleNotFoundError: SqliteSaver -> MemorySaver
from langgraph.checkpoint.memory import MemorySaver

# ============ 2. STATE + INPUT/OUTPUT ============


class GameRecommenderState(TypedDict):
    messages: Annotated[list, add_messages]
    envie_originale: str
    envie_reecrite: str
    jeux_trouves: list
    nombre_trouves: int
    player_id: str
    rage_level: Annotated[int, operator.add]


class GameInput(TypedDict):
    messages: list


class GameOutput(TypedDict):
    messages: list
    nombre_trouves: int
    jeux_trouves: list

# ============ 3. NODES (version light sans PGVector pour le test) ============


def chatbot_accueil(state: GameRecommenderState):
    last_msg = state["messages"][-1].content
    print(f"\n[CHATBOT] Demande: {last_msg}")
    return {
        "envie_originale": last_msg,
        "player_id": state.get("player_id", "gamin_rageux_12"),
        "rage_level": 1
    }


def reecrire_demande(state: GameRecommenderState):
    messages_utiles = filter_messages(
        state["messages"],
        include_types=[HumanMessage]
    )[-3:]
    historique = "\n".join([m.content for m in messages_utiles])
    reecrite = f"{state['envie_originale']} (reformulé)"
    print(f"[RRR] '{state['envie_originale']}' -> '{reecrite}'")
    return {
        "envie_reecrite": reecrite,
        "messages": [AIMessage(content=f"Ok je cherche: {reecrite}")]
    }


def chercher_dans_catalogue(state: GameRecommenderState):
    # Simulation sans PGVector pour que le chap_5 tourne sans base
    query = state["envie_reecrite"]
    results = [("Elden Ring - PC, PS5", 0.1), ("Hollow Knight - PC", 0.2)]
    reponse = f"Pour '{query}', je te conseille Elden Ring et Hollow Knight"
    print(f"[CATALOGUE] Query: {query} -> {len(results)} resultats")
    return {
        "jeux_trouves": results,
        "nombre_trouves": len(results),
        "messages": [AIMessage(content=reponse)]
    }


# ============ 4. BUILDER ============
builder = StateGraph(GameRecommenderState, input=GameInput, output=GameOutput)

builder.add_node("chatbot", chatbot_accueil)
builder.add_node("rrr", reecrire_demande)
builder.add_node("fusion", chercher_dans_catalogue)

builder.add_edge(START, "chatbot")
builder.add_edge("chatbot", "rrr")
builder.add_edge("rrr", "fusion")
builder.add_edge("fusion", END)

checkpointer = MemorySaver()
graph = builder.compile(checkpointer=checkpointer)

# ============ 5. TEST ============
if __name__ == "__main__":
    config = {"configurable": {"thread_id": "gamin_rageux_12"}}

    print("\n=== TOUR 1: 'Je veux un jeu gore ou on tire' ===")
    result = graph.invoke(
        {"messages": [HumanMessage(content="Je veux un jeu gore ou on tire")]},
        config=config
    )
    print(f"Sortie: {result['messages'][-1].content}")
    print(f"rage_level caché ? {result.get('rage_level')}")

    print("\n=== TOUR 2: 'Et avec des zombies' ===")
    result2 = graph.invoke(
        {"messages": [HumanMessage(content="Et avec des zombies")]},
        config=config
    )
    print(result2["messages"][-1].content)
