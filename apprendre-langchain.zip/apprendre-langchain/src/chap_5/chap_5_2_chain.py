"""
chain_nemotron_reel.py - VERSION CORRIGEE
Architecture #2 : Chain en condition réelle avec ton Nemotron 3
"""

from src import model
from typing import TypedDict, Annotated
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langchain_core.messages import HumanMessage, SystemMessage

# On augmente les timeouts pour l'ultra, il est énorme
# Si ton src/model.py ne met pas timeout, on le surcharge ici :
try:
    model.timeout = 60
except:
    pass

# ============ 1. LES 3 BOITES ============


class GameState(TypedDict):
    messages: Annotated[list, add_messages]
    envie_gamin: str
    jeu_trouve: str
    pourquoi_ce_jeu: str


class GameInput(TypedDict):
    envie_gamin: str


class GameOutput(TypedDict):
    jeu_trouve: str
    pourquoi_ce_jeu: str

# ============ 2. LES 2 OUVRIERS ============


generate_prompt = SystemMessage(
    content="Tu es un expert jeux vidéo. Propose UN SEUL jeu. Réponds uniquement avec le nom du jeu, rien d'autre. Ex: DOOM Eternal"
)

explain_prompt = SystemMessage(
    content="Tu es un vendeur cool qui parle à un gamin. Explique en 2 phrases max pourquoi ce jeu est parfait. Ton fun, pas technique."
)


def trouver_jeu(state: GameState):
    # FIX : state.get("messages", []) au cas où c'est None au démarrage
    # Et on n'imprime plus l'objet model entier !
    user_message = HumanMessage(content=state["envie_gamin"])
    history = state.get("messages") or []
    messages = [generate_prompt, *history, user_message]

    res = model.invoke(messages)

    # FIX : on imprime .model pour avoir juste le nom
    print(f"[OUVRIER 1 - {model.model}] -> {res.content}")

    return {
        "jeu_trouve": res.content.strip(),
        "messages": [user_message, res]
    }


def expliquer_jeu(state: GameState):
    context_message = HumanMessage(
        content=f"Le jeu trouvé est : {state['jeu_trouve']}")
    history = state.get("messages") or []
    messages = [explain_prompt, *history, context_message]

    res = model.invoke(messages)

    print(f"[OUVRIER 2 - {model.model}] -> {res.content}")

    return {
        "pourquoi_ce_jeu": res.content.strip(),
        "messages": [res]
    }

# ============ 3. LA CHAINE ============


builder = StateGraph(GameState, input=GameInput, output=GameOutput)
builder.add_node("trouver", trouver_jeu)
builder.add_node("expliquer", expliquer_jeu)

builder.add_edge(START, "trouver")
builder.add_edge("trouver", "expliquer")
builder.add_edge("expliquer", END)

graph = builder.compile()

# ============ 4. TEST REEL ============

if __name__ == "__main__":
    print("=== Test Chain Nemotron ===\n")

    result = graph.invoke({
        "envie_gamin": "jveux un jeu gore où on tir avec un shotgun"
    })

    print("\n=== RESULTAT FINAL (Output) ===")
    print(f"Jeu : {result['jeu_trouve']}")
    print(f"Pourquoi : {result['pourquoi_ce_jeu']}")
