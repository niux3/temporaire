from src import model
from typing import TypedDict, Annotated
from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages

# ============ 1. LES 3 BOITES ============


class GameState(TypedDict):
    messages: Annotated[list, add_messages]
    route_choisie: str
    envie_gamin: str
    jeu_trouve: str
    pourquoi_ce_jeu: str


class GameInput(TypedDict):
    envie_gamin: str


class GameOutput(TypedDict):
    jeu_trouve: str


# ============ 2. LES 2 OUVRIERS ============

prompt_patron = SystemMessage(
    content="""Tu es le patron d'un magasin de jeux vidéo.
Tu as 3 experts :
- fps : jeux de tir, gore, shotgun, démons
- plateforme : jeux de saut, mario, chill
- rpg : jeux de quête, histoire, Elden Ring
Demande du gamin : tu dois choisir UN SEUL expert.
Réponds UNIQUEMENT par un mot : fps, plateforme ou rpg."""
)


def patron_agent(state: GameState):
    msg = HumanMessage(content=state["envie_gamin"])
    res = model.invoke([prompt_patron, msg])

    choix = res.content.strip().lower()
    print(
        f"[PATRON AGENT - {model.model}] J'ai compris '{state['envie_gamin']}' -> je route vers {choix}")
    return {"route_choisie": choix}


def expert_fps(state):
    return {"jeu_trouve": "DOOM Eternal"}


def expert_plateforme(state):
    return {"jeu_trouve": "Hollow Knight"}


def expert_rpg(state):
    return {"jeu_trouve": "Elden Ring"}


builder = StateGraph(GameState, input=GameInput, output=GameOutput)
builder.add_node("patron_agent", patron_agent)
builder.add_node("expert_fps", expert_fps)
builder.add_node("expert_plateforme", expert_plateforme)
builder.add_node("expert_rpg", expert_rpg)

builder.add_edge(START, "patron_agent")


def router_decision(state):
    # Ici c'est l'Agent Router : il décide tout seul
    return state["route_choisie"]  # "fps" ou "plateforme" ou "rpg"


"""
builder.add_conditional_edges("NOM_DU_NOEUD_SOURCE", fonction_qui_decide, {
    "CE_QUE_RETOURNE_LA_FONCTION": "NOM_DU_NOEUD_DESTINATION"
})
"""
builder.add_conditional_edges("patron_agent", router_decision, {
    "fps": "expert_fps",
    "plateforme": "expert_plateforme",
    "rpg": "expert_rpg"
})
builder.add_edge("expert_fps", END)
builder.add_edge("expert_plateforme", END)
builder.add_edge("expert_rpg", END)

graph = builder.compile()

# ============ 4. TEST ============
if __name__ == "__main__":
    print("=== Test Chain Nemotron ===\n")
    result = graph.invoke(
        {"envie_gamin": "jveux un jeu gore où on tir avec un shotgun"})
    print("\n=== RESULTAT FINAL (Output) ===")
    print(f"Jeu : {result['jeu_trouve']}")
