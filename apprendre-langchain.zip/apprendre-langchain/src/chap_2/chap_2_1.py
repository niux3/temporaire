from pprint import pprint
from src import base_path
from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter


loader = TextLoader(str(base_path / "data" / "jeux-videos.txt"))
document_text = loader.load()

splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
splitter_doc = splitter.split_documents(document_text)


pprint(splitter_doc, indent=2)
