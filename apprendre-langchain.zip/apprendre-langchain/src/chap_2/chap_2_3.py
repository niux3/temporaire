from src import nemotron_embed, base_path, dns_psql
from langchain_community.document_loaders import TextLoader
from langchain_nvidia_ai_endpoints import NVIDIAEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_postgres import PGVector


raw_documents = TextLoader(str(base_path / "data" / "jeux-videos.txt")).load()
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,
    chunk_overlap=200
)

documents = text_splitter.split_documents(raw_documents)

embedding_model = NVIDIAEmbeddings(model=nemotron_embed)
db = PGVector.from_documents(documents, embedding_model, connection=dns_psql)

query = "quels sont les grands genres de jeux vidéos ?"
results = db.similarity_search_with_score(query, k=3)

print(f"\n🔎 Query: {query}\n")
for i, (doc, score) in enumerate(results, 1):
    print(
        f"--- Résultat {i} | score={score:.4f} (plus petit = plus proche) ---"
    )
    print(doc.page_content.strip())
    print(f"metadata: {doc.metadata}")
    print()
