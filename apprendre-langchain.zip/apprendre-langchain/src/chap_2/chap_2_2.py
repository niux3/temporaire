from src import nemotron_embed
from langchain_nvidia_ai_endpoints import NVIDIAEmbeddings
import numpy as np


model = NVIDIAEmbeddings(model=nemotron_embed)


documents = [
    "La nourriture était délicieuse et le serveur...",
    "Je retournerais sans hésiter pour...",
    "Le service était attentionné et la nourriture...",
]
embeddings = model.embed_documents(documents)

# print(embeddings)


def cosine(a, b):
    return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))


print(
    f"Phrase 0 vs 1 (2 avis resto): {cosine(embeddings[0], embeddings[1]):.3f}"
)
print(
    f"Phrase 0 vs 2 (2 avis resto): {cosine(embeddings[0], embeddings[2]):.3f}"
)
