from pprint import pprint
from src import model
from langchain_core.messages import HumanMessage


prompt = [
    HumanMessage("Quelle est la capitale de l'Espagne ?")
]
response = model.invoke(prompt)

pprint(response.content, indent=2)
