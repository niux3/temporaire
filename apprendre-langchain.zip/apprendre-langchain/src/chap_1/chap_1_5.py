from src import model
from langchain_core.prompts import ChatPromptTemplate


template = ChatPromptTemplate.from_messages([
    ("system", "Répondez à la question en français en vous basant sur le contexte ci-dessous. Si la question ne peut pas trouver de réponse à l'aide des informations fournies, répondez « Je ne sais pas »."),
    ("human", "context : {context}"),
    ("human", "question : {question}"),
])

chain = template | model

response = chain.invoke({
    "context": """Les avancées les plus récentes en matière de traitement du langage naturel (NLP) sont portées par les grands modèles de langage (LLM). Ces modèles surpassent leurs homologues de plus petite taille et sont devenus indispensables aux développeurs qui créent des applications dotées de capacités NLP. Les développeurs peuvent exploiter ces modèles via la bibliothèque `transformers` de Hugging Face, ou en utilisant les solutions d'OpenAI et de Cohere grâce aux bibliothèques `openai` et `cohere`, respectivement.""",
    "question": "Quels fournisseurs de modèles proposent des LLM ?"
})


print(response.content)
