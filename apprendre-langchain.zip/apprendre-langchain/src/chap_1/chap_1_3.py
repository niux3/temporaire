from pprint import pprint
from src import model
from langchain_core.messages import HumanMessage, SystemMessage


prompt = [
    SystemMessage(
        "Vous êtes un agent qui écrit des résumés succinct de texte. Chaque phrase se termine par 3 points d'exclamations"
    ),
    HumanMessage("Quelle est la capitale de l'Italie ?")
]
response = model.invoke(prompt)

pprint(response.content, indent=2)
