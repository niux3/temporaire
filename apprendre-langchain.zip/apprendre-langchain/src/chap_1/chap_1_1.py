from pprint import pprint
from src import model


response = model.invoke("Quelle est la capitale de France ?")

pprint(response.content, indent=2)
