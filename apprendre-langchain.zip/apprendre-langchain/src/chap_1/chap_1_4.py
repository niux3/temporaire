from pprint import pprint
from src import model
from langchain_core.prompts import PromptTemplate


template = PromptTemplate.from_template("""
       Répondez à la question en vous basant sur le contexte ci-dessous. Si les informations fournies ne permettent pas de répondre à la question, répondez « Je ne sais pas »
       context : {context}
       question : {question}
       réponse :
""")

chain = template | model

response = chain.invoke({
    "context": """Les dernières avancées en matière de TALN sont portées par les grands 
        modèles linguistiques (LLM). Ces modèles surpassent leurs homologues de plus petite taille 
        et sont devenus indispensables pour les développeurs qui créent 
        des applications dotées de capacités de TALN. Les développeurs peuvent exploiter ces 
        modèles via la bibliothèque `transformers` de Hugging Face, ou en utilisant 
        les solutions proposées par OpenAI et Cohere via les bibliothèques `openai` et `cohere` 
        respectivement. """,
    "question": "Quels fournisseurs proposent des modèles de langage de grande envergure (LLM) ?"
})


pprint(response.content, indent=2)
