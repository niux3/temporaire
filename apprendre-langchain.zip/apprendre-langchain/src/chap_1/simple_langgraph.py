import os
from typing import Annotated, TypedDict
from src import model_qwen
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.messages import HumanMessage
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages


class State(TypedDict):
    messages: Annotated[list, add_messages]
    context: str


def chatbot(state: State):
    prompt = ChatPromptTemplate.from_messages([
        ("system", "Tu es expert en {context}"),
        MessagesPlaceholder(variable_name="messages")
    ])
    chain = prompt | model_qwen

    answer = chain.invoke({
        "messages": state["messages"],
        "context": state["context"]
    })
    return {"messages": [answer]}


builder = StateGraph(State)
builder.add_node("chatbot", chatbot)
builder.add_edge(START, 'chatbot')
builder.add_edge('chatbot', END)

graph = builder.compile()

if __name__ == '__main__':
    def print_row(car='*'):
        print(f"\n{car * os.get_terminal_size().columns}\n")

    def ask_or_quit(prompt):
        quit = ['q', 'quit', 'exit']
        val = input(prompt).strip()
        if val.lower() in quit:
            raise SystemExit
        return val

    while True:
        try:
            print_row()
            expert = ask_or_quit("Quel context ? ")
            ask = ask_or_quit("Quelle question veux tu poser ? ")
            print_row('-')
            result = graph.invoke({
                "messages": [HumanMessage(content=ask)],
                "context": expert
            })
            print(result["messages"][-1].content)
        except (SystemExit, KeyboardInterrupt):
            print("\n\nAu revoir ! ")
            break
