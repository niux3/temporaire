import sqlite3
from src import base_path, model
from langchain_core.prompts import ChatPromptTemplate


conn = sqlite3.connect(str(base_path / "data" / "chinook.db"))
cursor = conn.cursor()

# Test
# cursor.execute("SELECT * FROM Genre")
# print(cursor.fetchall())

system_prompt = """
Tu es l'assistant SQL du disquaire Chinook.

SCHEMA COMPLET:
- Artist(ArtistId, Name)
- Album(AlbumId, Title, ArtistId)
- Track(TrackId, Name, AlbumId, GenreId, MediaTypeId, Composer, Milliseconds, Bytes, UnitPrice)
- Genre(GenreId, Name) -> ex: 'Rock', 'Jazz', 'Metal', 'Blues'
- Customer(CustomerId, FirstName, LastName, Country, City)
- Employee(EmployeeId, FirstName, LastName, Title)
- Invoice(InvoiceId, CustomerId, InvoiceDate, Total)
- InvoiceLine(InvoiceLineId, InvoiceId, TrackId, UnitPrice, Quantity)
- Playlist(PlaylistId, Name)
- PlaylistTrack(PlaylistId, TrackId)
- MediaType(MediaTypeId, Name)

REGLES:
- Réponds UNIQUEMENT avec une requête SQL SELECT valide SQLite
- Utilise JOIN pour lier les tables
- Pas de UPDATE, DELETE, INSERT
- Si la question est floue, fais une requête qui aide

Question: {question}
SQL:
"""

router_prompt = ChatPromptTemplate.from_template(system_prompt)

chain = router_prompt | model


def poser_question(question: str):
    print(f"\n👤 TOI: {question}")

    # ÉTAPE 1: Le model génère le SQL
    sql_brut = chain.invoke({"question": question}).content
    sql = sql_brut.replace("```sql", "").replace("```", "").strip()
    print(f"🤖 MODEL (SQL généré): {sql}")

    # ÉTAPE 2: Ton code exécute le SQL sur chinook.db
    try:
        cursor.execute(sql)
        rows = cursor.fetchall()
        cols = [d[0] for d in cursor.description]
        print(f"💾 COLONNE: {cols}")

        # ÉTAPE 3: On te rend le résultat
        print(f"💾 BASE (Résultat): {len(rows)} lignes")
        print(f"{'*' * 80}\n")
        for r in rows[:10]:  # affiche les 10 premières
            print(f" {r}")
        if len(rows) > 10:
            print(f"... et {len(rows)-10} autres")

        return rows

    except Exception as e:
        print(f"❌ Erreur SQL: {e}")
        return None


# BOUCLE - Tu discutes avec ta base
if __name__ == "__main__":
    while True:
        q = input("\nPose ta question sur Chinook (ou 'exit'): ")
        if q.lower() in ["exit", "quit", "q"]:
            break
        poser_question(q)
