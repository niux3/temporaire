from src import base_path, model, dns_psql, nemotron_embed
from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_postgres import PGVector
from langchain_nvidia_ai_endpoints import NVIDIAEmbeddings
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda


# 1. INIT (les 4 points que tu as cités)
raw = TextLoader(str(base_path / "data" / "jeux-videos.txt")).load()
splits = RecursiveCharacterTextSplitter(
    chunk_size=500,
    chunk_overlap=100
).split_documents(raw)
db = PGVector.from_documents(
    splits,
    NVIDIAEmbeddings(model=nemotron_embed),
    connection=dns_psql,
    collection_name="jeux_video_final"
)
retriever = db.as_retriever(search_kwargs={"k": 2})

# 2. GENERATEUR DE 3 QUESTIONS (ta définition)
gen_prompt = ChatPromptTemplate.from_template(
    "Génère 3 versions différentes de cette question jeux vidéo, une par ligne: {question}")


def parse(m): return [l.strip()
                      for l in m.content.split('\n') if l.strip()][:3]


query_gen = gen_prompt | model | RunnableLambda(parse)

# 3. LA CHAINE QUI FAIT TOUT


def full_rag(x):
    print(f"\nQuestion floue: {x['question']}")
    queries = query_gen.invoke(x)
    print(f"-> Transformée en: {queries}")

    all_docs = []
    for q in queries:
        all_docs.extend(retriever.invoke(q))

    # dédup simple
    unique = list({d.page_content: d for d in all_docs}.values())

    final_prompt = ChatPromptTemplate.from_template(
        "Contexte: {context}\nQuestion: {question}\nRéponds simplement.")
    return (final_prompt | model).invoke({"context": unique, "question": x['question']})


chain = RunnableLambda(full_rag)

# 4. LANCE
if __name__ == "__main__":
    res = chain.invoke(
        {"question": "je veux un truc chill où on farm sans se prendre la tête"})
    print("\n--- REPONSE FINALE ---\n", res.content)
