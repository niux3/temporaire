# Memo

- [x] Réécrire-Récupérer-Lire (lorsque la question est vague)
- [x] RAG-Fusion (évite que la réponse se répète)
- [x] HyDE (invente un document qui répond à la question)
- [ ] Filtre texte-métadonnées (insertion de tags lors de PGVector, etc.)
- [x] Routage Logique (Analyse la question du client pour l'aiguiller vers la bonne branche (retriever / collection / prompt) qui va produire la bonne réponse. )
- [ ] Routage Sémantique (Embed la question (On transforme la question du client en chiffre) et l'aiguille vers la route la plus proche sémantiquement.)
- [ ] Du texte à SQL (fait une recherche en base de données, mais donne la requête SQL pour le faire manuellement)
