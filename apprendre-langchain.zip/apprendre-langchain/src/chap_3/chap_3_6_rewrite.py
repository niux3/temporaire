from src import base_path, model, dns_psql, nemotron_embed
from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_postgres import PGVector
from langchain_nvidia_ai_endpoints import NVIDIAEmbeddings
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda


# 1. INIT (les 4 points que tu as cités)
raw = TextLoader(str(base_path / "data" / "jeux-videos.txt")).load()
splits = RecursiveCharacterTextSplitter(
    chunk_size=500,
    chunk_overlap=100
).split_documents(raw)
db = PGVector.from_documents(
    splits,
    NVIDIAEmbeddings(model=nemotron_embed),
    connection=dns_psql,
    collection_name="jeux_video_rewite"
)
retriever = db.as_retriever(search_kwargs={"k": 2})

# print("base prête")

rewrite_prompt = ChatPromptTemplate.from_template(
    """Tu es un traducteur pour un moteur de recherche de jeux vidéo.
L'utilisateur parle mal, est vague, ou rage.
Ta mission : réécrire sa question en une seule question claire, précise, et optimisée pour une recherche vectorielle.

Ne réponds PAS à la question. Réécris-la seulement.

Exemples:
- Entrée: "ce jeu il lag sa mère" -> Sortie: "Quels sont les problèmes de performance et d'optimisation connus pour ce jeu ?"
- Entrée: "j'veux un truc qui fait peur" -> Sortie: "Quels sont les meilleurs jeux vidéo d'horreur et de survival horror ?"
- Entrée: "truc chill farm" -> Sortie: "Quels sont les jeux vidéo de type cozy game et farming simulator relaxant ?"

Question à réécrire: {question}"""
)

rewriter = rewrite_prompt | model

# test = rewriter.invoke({"question": "ce jeu il est cassé il rame"})
# print(f"\nQuestion rageuse -> Question propre: {test.content}\n")

final_prompt = ChatPromptTemplate.from_template(
    """Tu es un expert jeux vidéo. Réponds en te basant UNIQUEMENT sur le contexte.

Contexte: {context}
Question originale de l'utilisateur: {question}
Question réécrite pour la recherche: {rewritten}

Réponds de manière simple et utile.""")


def full_rewrite_rag(input_dict):
    original_question = input_dict["question"]

    # 1. REECRIRE
    rewritten_msg = rewriter.invoke({"question": original_question})
    rewritten_question = rewritten_msg.content
    print(f">> Original: {original_question}")
    print(f">> Réécrite: {rewritten_question}")

    # 2. RECUPERER
    docs = retriever.invoke(rewritten_question)
    print(f">> {len(docs)} docs trouvés")

    # 3. LIRE (générer la réponse finale)
    answer = (final_prompt | model).invoke({
        "context": docs,
        "question": original_question,
        "rewritten": rewritten_question
    })
    return answer


chain = RunnableLambda(full_rewrite_rag)

if __name__ == "__main__":
    questions_pourries = [
        "ce jeu il lag sa mère",
        "j'veux un truc qui fait peur",
        "un jeu où on tire partout mais chill"
    ]

    for q in questions_pourries:
        print("\n" + "="*60)
        res = chain.invoke({"question": q})
        print(res.content)
