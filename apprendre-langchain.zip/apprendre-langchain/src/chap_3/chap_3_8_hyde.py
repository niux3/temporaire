from collections import defaultdict
from src import base_path, model, dns_psql, nemotron_embed
from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_postgres import PGVector
from langchain_nvidia_ai_endpoints import NVIDIAEmbeddings
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda


# 1. INIT (les 4 points que tu as cités)
raw = TextLoader(str(base_path / "data" / "jeux-videos.txt")).load()
splits = RecursiveCharacterTextSplitter(
    chunk_size=500,
    chunk_overlap=100
).split_documents(raw)
db = PGVector.from_documents(
    splits,
    NVIDIAEmbeddings(model=nemotron_embed),
    connection=dns_psql,
    collection_name="jeux_video_rewite"
)
retriever = db.as_retriever(search_kwargs={"k": 2})

# print("base prête")
hyde_prompt = ChatPromptTemplate.from_template(
    """Tu es un expert jeux vidéo. Tu dois écrire un faux paragraphe de fiche produit qui RÉPONDRAIT à la question.

Tu n'as pas besoin que ce soit vrai. Invente un document plausible, avec beaucoup de détails, comme si c'était une page wiki.

Question: {question}

Faux document (écris 3-4 phrases, style fiche de jeu vidéo, avec genre, gameplay, ambiance):
"""
)

# Test
# fake_doc = (hyde_prompt | model).invoke(
#     {"question": "j'veux un truc qui fait peur mais où on construit un peu"})
# print(fake_doc.content)
# -> "The Forest est un survival horror en monde ouvert où le joueur doit construire des abris en bois..."


def hyde_rag(input_dict):
    question = input_dict["question"]

    # 1. GÉNÈRE UN FAUX DOC
    fake_doc_text = (hyde_prompt | model).invoke(
        {"question": question}).content
    print(f"\n>> Question originale: {question}")
    print(f">> Faux document inventé: {fake_doc_text[:150]}...")

    # 2. CHERCHE AVEC LE FAUX DOC (c'est ça HyDE)
    # Avant on faisait: retriever.invoke(question)
    # Maintenant on fait:
    docs = retriever.invoke(fake_doc_text)

    print(
        f">> Docs trouvés avec le faux doc: {[d.page_content[:60] for d in docs]}")

    # 3. RÉPONDS avec les vrais docs
    final_prompt = ChatPromptTemplate.from_template(
        """Contexte réel de la base: {context}
    Question originale: {question}
    Réponds en utilisant UNIQUEMENT le contexte réel. Si le contexte ne suffit pas, dis-le.
    """)

    answer = (final_prompt | model).invoke(
        {"context": docs, "question": question})
    return answer


chain = RunnableLambda(hyde_rag)

if __name__ == "__main__":
    result = chain.invoke(
        {"question": "j'veux un truc qui fait peur mais où on construit un peu"})
    print("\n--- REPONSE FINALE ---\n", result.content)
