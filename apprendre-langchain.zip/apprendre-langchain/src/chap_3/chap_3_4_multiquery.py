from src import base_path, nemotron_embed, dns_psql, model
from langchain_community.document_loaders import TextLoader
from langchain_nvidia_ai_endpoints import NVIDIAEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_postgres import PGVector
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda


raw = TextLoader(str(base_path / "data" / "jeux-videos.txt")).load()
splits = RecursiveCharacterTextSplitter(
    chunk_size=1000,
    chunk_overlap=200
).split_documents(raw)

embed = NVIDIAEmbeddings(model=nemotron_embed)

db = PGVector.from_documents(
    splits,
    embed,
    connection=dns_psql,
    collection_name="jeux_video_multiquery"
)

retriever = db.as_retriever(search_kwargs={"k": 2})

perspectives_prompt = ChatPromptTemplate.from_template("""
Tu es un expert jeux vidéo.
Ta mission est de générer 3 versions différentes de la question de l'utilisateur
pour chercher dans une base de données de jeux vidéo.
Objectif : surmonter les limites de la recherche par similarité.

Fournis 3 questions alternatives, une par ligne, sans numérotation.
Question originale: {question}
""")


def parse_queries_output(message):
    # le modèle renvoie un texte avec \n, on le transforme en liste Python
    queries = [q.strip() for q in message.content.split('\n') if q.strip()]
    return queries[:3]


query_gen_chain = perspectives_prompt | model | parse_queries_output

# q = "je veux un truc où on tire partout"
# print(query_gen_chain.invoke(q))


def retrieve_for_all_queries(input_dict):
    question = input_dict["question"]
    queries = query_gen_chain.invoke({"question": question})
    print(f"\n>> Questions générées: {queries}\n")

    # 2. Pour chaque question, cherche des docs
    all_docs = []
    for q in queries:
        docs = retriever.invoke(q)
        all_docs.extend(docs)

    return {"all_docs": all_docs, "question": question}


multi_step = RunnableLambda(retrieve_for_all_queries)


def dedup_and_format(input_dict):
    # évite d'avoir 2x le même chunk
    seen = set()
    unique_docs = []
    for doc in input_dict["all_docs"]:
        if doc.page_content not in seen:
            unique_docs.append(doc)
            seen.add(doc.page_content)

    print(
        f">> {len(input_dict['all_docs'])} docs trouvés, {len(unique_docs)} après dédup")
    return {"context": unique_docs, "question": input_dict["question"]}


final_prompt = ChatPromptTemplate.from_template("""
Réponds à la question en te basant UNIQUEMENT sur le contexte suivant.
Contexte: {context}
Question: {question}
""")

# LA CHAINE FINALE
final_chain = multi_step | dedup_and_format | final_prompt | model

if __name__ == "__main__":
    while True:
        q = input("\nQuelle est ta question jeux vidéo ? (q pour quitter) ")
        if q in ["q", "quit", "exit"]:
            break
        res = final_chain.invoke({"question": q})
        print("\n--- REPONSE ---\n", res.content)
