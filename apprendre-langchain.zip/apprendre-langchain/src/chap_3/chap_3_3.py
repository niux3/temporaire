from pprint import pprint
from src import base_path, nemotron_embed, dns_psql, model
from langchain_community.document_loaders import TextLoader
from langchain_nvidia_ai_endpoints import NVIDIAEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_postgres import PGVector
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import chain


raw_documents = TextLoader(str(base_path / "data" / "jeux-videos.txt")).load()
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,
    chunk_overlap=200
)

documents = text_splitter.split_documents(raw_documents)

embedding_model = NVIDIAEmbeddings(model=nemotron_embed)
db = PGVector.from_documents(documents, embedding_model, connection=dns_psql)

retriever = db.as_retriever()

prompt = ChatPromptTemplate.from_template("""
 Répondre à la question suivant le contexte donné. 
 contexte: {context}
 question: {question}
""")


@chain
def qa(input):
    docs = retriever.invoke(input)
    formatted = prompt.invoke({"context": docs, "question": input})
    answer = model.invoke(formatted)
    return answer


query = "quels sont les grands genres de jeux vidéos ?"
results = qa.invoke(query)

print(results.content)
