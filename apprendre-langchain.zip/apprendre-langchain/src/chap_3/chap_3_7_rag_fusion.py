from collections import defaultdict
from src import base_path, model, dns_psql, nemotron_embed
from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_postgres import PGVector
from langchain_nvidia_ai_endpoints import NVIDIAEmbeddings
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda


# 1. INIT (les 4 points que tu as cités)
raw = TextLoader(str(base_path / "data" / "jeux-videos.txt")).load()
splits = RecursiveCharacterTextSplitter(
    chunk_size=500,
    chunk_overlap=100
).split_documents(raw)
db = PGVector.from_documents(
    splits,
    NVIDIAEmbeddings(model=nemotron_embed),
    connection=dns_psql,
    collection_name="jeux_video_rewite"
)
retriever = db.as_retriever(search_kwargs={"k": 2})

# print("base prête")

gen_prompt = ChatPromptTemplate.from_template(
    """Tu es un expert jeux vidéo. L'utilisateur pose une question floue.
Génère 3 versions DIFFÉRENTES de sa question pour couvrir tous les angles possibles.
Une question par ligne, pas de numéros.

Exemples:
Question: "j'veux un truc qui fait peur mais où on construit"
Sortie:
Quels sont les jeux de survival horror avec construction de base?
Quels sont les jeux sandbox horrifiques type Minecraft?
Quels sont les jeux de gestion de colonie avec menace de monstres?

Question: {question}"""
)


def parse_queries(msg):
    # on nettoie le retour du LLM
    return [l.strip() for l in msg.content.split('\n') if l.strip()][:3]


query_gen = gen_prompt | model | RunnableLambda(parse_queries)

# Test rapide
# q = {"question": "truc qui fait peur mais où on construit"}
# results = query_gen.invoke(q)
# print(results)


# formule magique pour le RRF
def reciprocal_rank_fusion(all_results, k=60):
    """
    all_results = liste de listes : [[doc1, doc2], [doc3, doc1], [doc4, doc1]]
    On fait le podium
    """
    scores = defaultdict(float)
    docs_by_content = {}

    for docs in all_results:
        for rank, doc in enumerate(docs):
            key = doc.page_content  # on déduplique par contenu
            docs_by_content[key] = doc
            # Formule RRF du papier : 1 / (k + rank)
            scores[key] += 1.0 / (k + rank + 1)

    # On trie par score décroissant
    sorted_keys = sorted(scores, key=lambda x: scores[x], reverse=True)
    return [docs_by_content[key] for key in sorted_keys]


final_prompt = ChatPromptTemplate.from_template(
    """Tu es un assistant pour le magasin MC Pixel.
Tu réponds UNIQUEMENT avec le CONTEXTE fourni. Si le contexte ne contient pas la réponse, dis-le clairement.

RÈGLE ANTI-HALLUCINATION:
- Si le contexte ne parle pas de construction + horreur, réponds: "Désolé, dans ma base actuelle je n'ai que {context}, je n'ai pas de jeu qui mélange horreur et construction. Veux-tu que j'ajoute The Forest à la base ?"
- N'invente JAMAIS un jeu qui n'est pas dans le contexte.

Contexte: {context}
Question originale: {question}

Réponse (basée uniquement sur le contexte):""")


def full_fusion_rag(input_dict):
    q = input_dict["question"]

    # 1. GÉNÈRE 3 QUESTIONS
    queries = query_gen.invoke({"question": q})
    print(f"\n>> Question originale: {q}")
    print(f">> 3 traductions: {queries}")

    # 2. RÉCUPÈRE 3 LISTES
    all_docs_lists = []
    for q_rewrite in queries:
        docs = retriever.invoke(q_rewrite)
        all_docs_lists.append(docs)
        print(
            f" - '{q_rewrite}' -> {[d.metadata.get('title', '?')[:20] for d in docs]}")

    # 3. FUSIONNE (PODIUM)
    fused_docs = reciprocal_rank_fusion(all_docs_lists)
    print(f">> Podium final: {[d.page_content[:40] for d in fused_docs[:3]]}")

    # 4. LIS
    answer = (final_prompt | model).invoke(
        {"context": fused_docs, "question": q})
    return answer


chain = RunnableLambda(full_fusion_rag)

if __name__ == "__main__":
    q = {"question": "j'veux un truc qui fait peur mais où on construit un peu"}
    result = chain.invoke(q)
    print("\n--- REPONSE FINALE ---\n", result.content)
