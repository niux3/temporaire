from src import base_path, nemotron_embed, dns_psql
from langchain_community.document_loaders import TextLoader
from langchain_nvidia_ai_endpoints import NVIDIAEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_postgres import PGVector


raw_documents = TextLoader(str(base_path / "data" / "jeux-videos.txt")).load()
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,
    chunk_overlap=200
)

documents = text_splitter.split_documents(raw_documents)

embedding_model = NVIDIAEmbeddings(model=nemotron_embed)
db = PGVector.from_documents(documents, embedding_model, connection=dns_psql)
