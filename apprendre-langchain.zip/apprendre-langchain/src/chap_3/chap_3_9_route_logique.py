from src import base_path, model, dns_psql, nemotron_embed
from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_postgres import PGVector
from langchain_nvidia_ai_endpoints import NVIDIAEmbeddings
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda

# Tes 3 fichiers sources
fichiers = {
    "fps": str(base_path / "data" / "fps.txt"),
    "rpg": str(base_path / "data" / "rpg.txt"),
    "plateforme": str(base_path / "data" / "plateforme.txt")
}

embed = NVIDIAEmbeddings(model=nemotron_embed)
db = None

for categorie, path in fichiers.items():
    raw = TextLoader(path).load()
    splits = RecursiveCharacterTextSplitter(
        chunk_size=500,
        chunk_overlap=100
    ).split_documents(raw)
    for d in splits:
        d.metadata["categorie"] = categorie

    if db is None:
        db = PGVector.from_documents(
            splits,
            embed,
            connection=dns_psql,
            collection_name="prod_mcpixel_jeux_fr_nemotron_v1"
        )
    else:
        db.add_documents(splits)


router_prompt = ChatPromptTemplate.from_template(
    """Tu es le chef d'orchestre du magasin MC Pixel. Tu ne réponds pas au client, tu dis quel vendeur doit s'en occuper.

Classe la question en UNE seule catégorie:

- fps: Le client veut un jeu de tir, avec des flingues, qui tire, doom, overwatch
- rpg: Le client veut une aventure, une histoire, witcher, baldur, niveaux, quêtes
- plateforme: Le client veut sauter, mario, jump, chill, farm
- titre_precis: Le client donne un nom exact de jeu: Ravendown, Overwatch, Elvenar
- autre: Il parle de lag, de bug, de performance, ou tu ne sais pas

Question: {question}

Réponds UNIQUEMENT par un mot: fps, rpg, plateforme, titre_precis, autre
"""
)

router = router_prompt | model

# Test
# -> titre_precis
# print(router.invoke({"question": "Ravendown c'est quoi?"}).content)
# print(router.invoke(
#     {"question": "j'veux un truc qui fait peur où on tire"}).content)  # -> fps
# print(router.invoke({"question": "ce jeu lag sa mère"}).content)  # -> autre

# Vendeur Kevin - FPS
retriever_fps = db.as_retriever(
    search_kwargs={"k": 3, "filter": {"categorie": "fps"}})

# Vendeur Léa - RPG
retriever_rpg = db.as_retriever(
    search_kwargs={"k": 3, "filter": {"categorie": "rpg"}})

# Vendeur Momo - Plateforme
retriever_plateforme = db.as_retriever(
    search_kwargs={"k": 3, "filter": {"categorie": "plateforme"}})

# Vendeur Généraliste - Quand on a un titre précis, on cherche partout
retriever_all = db.as_retriever(search_kwargs={"k": 3})


final_prompt = ChatPromptTemplate.from_template(
    """Tu es vendeur chez MC Pixel. Réponds avec le contexte.

Contexte (trouvé par le vendeur {categorie}): {context}
Question du client: {question}
"""
)


def magasin_avec_chef(input_dict):
    question = input_dict["question"]

    # 1. LE CHEF ECOUTE
    route = router.invoke({"question": question}).content.strip()
    print(f"[CHEF] Question '{question}' -> Je l'envoie chez: {route}")

    # 2. LE VENDEUR CHERCHE
    if route == "fps":
        docs = retriever_fps.invoke(question)
    elif route == "rpg":
        docs = retriever_rpg.invoke(question)
    elif route == "plateforme":
        docs = retriever_plateforme.invoke(question)
    else:  # titre_precis ou autre
        docs = retriever_all.invoke(question)

    # 3. ON EXTRAIT LES NOMS (c'est ça qui manquait)
    titres = []
    for d in docs:
        # Ton fichier a "TITRE: Ravendown" dans le texte
        for ligne in d.page_content.split("\n"):
            if ligne.startswith("TITRE:"):
                titres.append(ligne.replace("TITRE:", "").strip())

    print(f"[{route}] {len(docs)} jeux trouvés -> {', '.join(titres)}")

    # 4. LE VENDEUR REPOND
    answer = (final_prompt | model).invoke({
        "context": docs,
        "question": question,
        "categorie": route
    })
    return answer


chain = RunnableLambda(magasin_avec_chef)

# TESTS
chain.invoke({"question": "Ravendown"})
# [CHEF] -> titre_precis -> cherche partout -> trouve Ravendown

chain.invoke({"question": "j'veux un fps qui fait peur"})
# [CHEF] -> fps -> cherche QUE dans fps -> trouve Nightforge, pas Stardew Valley -> plus pertinent

chain.invoke({"question": "un jeu chill farm"})
# [CHEF] -> plateforme -> cherche QUE dans plateforme -> trouve Elvenar
